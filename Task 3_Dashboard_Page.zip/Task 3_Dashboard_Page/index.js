fetch("courses.json")
    .then(function (response) {
        return response.json();
    })
    .then(function (courses) {
        console.log(courses);
        let content__body = document.querySelector(".content__body");
        const showInHtml = courses.map(function (course, index){
            return `
                <div class="card">
                    <div class="card_img">
                        <img src=${encodeURI(course.imgUrl)} alt="">
                    </div>
                    <div class="card_info">
                    <div class="course_name">
                        <p>${course.courseName}</p>
                        <img src="quantum screen assets/icons/favourite.svg" alt="">
                    </div>
                    <div class="course_subject">${course.courseSubject} &nbsp;|&nbsp; Grade ${course.courseGrade} <span>+${course.additionalCourseGrade}</span>
                    </div>
                    <div class="course_length">
                        ${course.courseLength.units} <span>Units </span>${course.courseLength.lessons} <span>Lessons</span> ${course.courseLength.topics} <span>Topics</span>
                    </div>
                    <div class="course_class">
                        <p${course.courseClass===null
                            ?` style="color:#686868"`
                            :``
                        }>
                        ${course.courseClass!==null
                            ?course.courseClass
                            :`No Classes`
                        }
                        </p>
                        <img src="quantum screen assets/icons/arrow-down.svg" alt="" />
                    </div> 

                    ${course.courseEnrollInfo.totalStudents!==null
                        ?`<div class="course_enroll_info">${course.courseEnrollInfo.totalStudents} students &nbsp;`
                        :
                        `<div class="course_enroll_info">`
                    }
                    ${course.courseEnrollInfo.startingDate!==null
                        ?`| &nbsp;${course.courseEnrollInfo.startingDate} - ${course.courseEnrollInfo.endingDate}</div>`
                        :`</div>`
                    }

                    </div>

                    <div class="card_footer">
                    <img src="quantum screen assets/icons/preview.svg" alt=""
                    ${!course.previewIsActive
                        ?` style="opacity : 40%"`
                        :``}
                    >
                    <img src="quantum screen assets/icons/manage course.svg " alt=""
                    ${!course.manageIsActive
                        ?` style="opacity : 40%"`
                        :``}
                    >
                    <img src="quantum screen assets/icons/grade submissions.svg" alt=""
                    ${!course.gradeIsActive
                        ?` style="opacity : 40%"`
                        :``}
                    >
                    <img src="quantum screen assets/icons/reports.svg" alt=""
                    ${!course.reportsIsActive
                        ?` style="opacity : 40%"`
                        :``}
                    >
                    </div>
                </div>
        `
        }).join('');

        content__body.innerHTML=showInHtml;
    })

